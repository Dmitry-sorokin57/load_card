function del_item(e) {
    item_id = event.path[0].id.slice(9)
    console.log(`Deleting item #${item_id}`)
    let xhr = new XMLHttpRequest()
    xhr.open("DELETE", `/api/items/${item_id}`, true)
    xhr.send(null)
    console.log(xhr.responseText)

    e.path[3].remove() // Delete card
}

function buy_item(e) {
    item_id = event.path[0].id.slice(9)
    console.log(`Buy item #${item_id}`)
    let xhr = new XMLHttpRequest()
    xhr.open("GET", `/api/buy_item/${item_id}`, true)
    xhr.send(null)
    console.log(xhr.responseText)
}